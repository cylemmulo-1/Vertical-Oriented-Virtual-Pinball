# focuser.ps1 — waits for VPX (by process name) to exit, then focuses our window once
param([int]$hwnd, [int]$vpxPid)

Add-Type @"
using System;
using System.Runtime.InteropServices;
public class W {
  [DllImport("user32.dll")] public static extern bool SetForegroundWindow(IntPtr h);
  [DllImport("user32.dll")] public static extern IntPtr GetForegroundWindow();
  [DllImport("user32.dll")] public static extern bool ShowWindow(IntPtr h, int n);
  [DllImport("user32.dll")] public static extern bool BringWindowToTop(IntPtr h);
  [DllImport("user32.dll")] public static extern uint GetWindowThreadProcessId(IntPtr h, out uint p);
  [DllImport("user32.dll")] public static extern bool AttachThreadInput(uint a, uint b, bool attach);
  [DllImport("user32.dll")] public static extern void keybd_event(byte vk, byte scan, uint flags, int extra);
  [DllImport("user32.dll")] public static extern bool IsWindow(IntPtr h);
}
"@

$target = [IntPtr]$hwnd

# Wait for VPX to exit — poll its process by PID
# Also watch for VPX child processes (some launchers spawn a child)
$vpxExited = $false
$maxWait = 300  # 150 seconds max wait for VPX to exit

for ($i = 0; $i -lt $maxWait; $i++) {
    Start-Sleep -Milliseconds 500

    # Check if original PID is gone
    $proc = Get-Process -Id $vpxPid -ErrorAction SilentlyContinue
    if ($proc -eq $null) {
        # Also wait a moment for any VPX child processes to clean up
        Start-Sleep -Milliseconds 1000
        $vpxExited = $true
        break
    }
}

if (-not $vpxExited) {
    Write-Host "VPX never exited, giving up"
    exit 1
}

# VPX is gone — now focus our window once using AttachThreadInput
Write-Host "VPX exited, focusing HWND $hwnd"

if (-not [W]::IsWindow($target)) {
    Write-Host "Target window no longer exists"
    exit 1
}

$fg = [W]::GetForegroundWindow()
$fgThread = [W]::GetWindowThreadProcessId($fg, [ref]0)
$myThread = [W]::GetWindowThreadProcessId($target, [ref]0)

[W]::AttachThreadInput($fgThread, $myThread, $true)
[W]::keybd_event(0, 0, 0, 0)
[W]::ShowWindow($target, 9)
[W]::BringWindowToTop($target)
[W]::SetForegroundWindow($target)
[W]::AttachThreadInput($fgThread, $myThread, $false)

Write-Host "done"
exit 0
