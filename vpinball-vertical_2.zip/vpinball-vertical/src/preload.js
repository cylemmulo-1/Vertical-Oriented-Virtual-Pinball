const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('api', {
  loadData:          ()        => ipcRenderer.invoke('load-data'),
  saveData:          (data)    => ipcRenderer.invoke('save-data', data),
  getDisplays:       ()        => ipcRenderer.invoke('get-displays'),
  launchTable:       (args)    => ipcRenderer.invoke('launch-table', args),
  scanFolder:        (args)    => ipcRenderer.invoke('scan-folder', args),
  getPinemhiScores:  (args)    => ipcRenderer.invoke('get-pinemhi-scores', args),
  browseExe:         ()        => ipcRenderer.invoke('browse-exe'),
  browseVpx:         ()        => ipcRenderer.invoke('browse-vpx'),
  browseFolder:      ()        => ipcRenderer.invoke('browse-folder'),
  listWheelImages:   (folder)  => ipcRenderer.invoke('list-wheel-images', folder),
  readImageBase64:   (fp)      => ipcRenderer.invoke('read-image-base64', fp),
  quit:              ()        => ipcRenderer.invoke('quit'),
  debugPinemhi:      (args)    => ipcRenderer.invoke('debug-pinemhi', args),
  readRawFile:       (args)    => ipcRenderer.invoke('read-raw-file', args),
  checkMissingFiles: (args)    => ipcRenderer.invoke('check-missing-files', args),
  identifyDisplay:   (idx)     => ipcRenderer.invoke('identify-display', idx),
});
