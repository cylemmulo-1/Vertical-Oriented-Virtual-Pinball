const { app, BrowserWindow, ipcMain, dialog, screen } = require('electron');
const path = require('path');
const fs = require('fs');
const { spawn, execFile, execSync } = require('child_process');

const DATA_FILE = path.join(app.getPath('userData'), 'vpinball-vertical.json');

const DEFAULT_DATA = {
  settings: {
    exePath: 'C:\\VPinball\\VPinballX64.exe',
    wheelPath: '',
    tableFolderPath: '',
    pinemhiFolder: '',   // folder containing pinemhi.ini + PINemHi LeaderBoard\
    displayIndex: 0,
    windowWidth: 2560,
    windowHeight: 1440,
    windowOffsetX: 0,  // shift window right to clear taskbar (px)
    windowOffsetY: 0,  // shift window down if needed
  },
  categories: ['All Tables', 'Classic', 'Modern', 'Originals', 'Favorites', 'WIP'],
  tables: [],
  deletedPaths: [],   // paths the user has removed — skip on re-scan
  recentlyPlayed: []
};

function loadData() {
  try {
    if (fs.existsSync(DATA_FILE)) {
      const raw = JSON.parse(fs.readFileSync(DATA_FILE, 'utf8'));
      raw.settings    = Object.assign({}, DEFAULT_DATA.settings, raw.settings);
      raw.categories  = raw.categories  || DEFAULT_DATA.categories;
      raw.tables      = raw.tables      || [];
      raw.deletedPaths= raw.deletedPaths|| [];
      raw.recentlyPlayed = raw.recentlyPlayed || [];
      return raw;
    }
  } catch (e) { console.error('loadData:', e); }
  return JSON.parse(JSON.stringify(DEFAULT_DATA));
}

function saveData(data) {
  try { fs.writeFileSync(DATA_FILE, JSON.stringify(data, null, 2), 'utf8'); return true; }
  catch (e) { console.error('saveData:', e); return false; }
}

// ── PINemHi ───────────────────────────────────────────────────────────────────
let iniCache = null;
let iniCachePath = null;

function loadPinemhiIni(iniPath) {
  if (iniCachePath === iniPath && iniCache) return iniCache;
  try {
    const text = fs.readFileSync(iniPath, 'utf8');
    const map = {}; // normalized display name -> rom name
    for (const raw of text.split(/\r?\n/)) {
      const line = raw.trim();
      if (!line || line.startsWith(';') || line.startsWith('[')) continue;
      if (!line.includes('=')) continue;
      const eq = line.indexOf('=');
      const name = line.slice(0, eq).trim();
      let rom = line.slice(eq + 1).trim().split(/[\s,]/)[0]; // first token
      // Strip file extensions — ini may store 'eatpm_11.nv' but we want 'eatpm_11'
      rom = rom.replace(/\.[a-z0-9]{1,4}$/i, '');
      if (name && rom) map[name.toLowerCase()] = rom.toLowerCase();
    }
    iniCache = map;
    iniCachePath = iniPath;
    console.log(`PINemHi ini loaded: ${Object.keys(map).length} entries`);
    return map;
  } catch(e) {
    console.error('loadPinemhiIni:', e.message);
    return null;
  }
}

function normPinemhi(s) {
  return s.toLowerCase()
    .replace(/\([^)]*\)/g, ' ')   // strip parens
    .replace(/\[[^\]]*\]/g, ' ')  // strip brackets
    .replace(/\bvr\b|\bmod\b|\bvpw\b/gi, ' ')
    .replace(/\bv\d+[\d.]*\b/gi, ' ')  // version numbers like v1.22
    .replace(/\d+\.\d+[\d.]*/g, ' ')   // bare version numbers like 1.22
    .replace(/[^a-z0-9 ]/g, ' ')
    .replace(/\s+/g, ' ').trim();
}

function fuzzyMatchIni(iniMap, wheelFile, tableName) {
  // Use wheel filename (cleaner, no version junk) as primary source
  const sourceName = wheelFile
    ? path.basename(wheelFile, path.extname(wheelFile))
    : tableName;
  const needle = normPinemhi(sourceName);
  const needleWords = needle.split(' ').filter(w => w.length > 1);
  if (!needleWords.length) return null;

  let bestRom = null, bestScore = 0;
  for (const [iniName, rom] of Object.entries(iniMap)) {
    const hay = normPinemhi(iniName);
    const hayWords = hay.split(' ').filter(w => w.length > 1);
    if (!hayWords.length) continue;

    const matches = needleWords.filter(w => hayWords.includes(w)).length;
    if (matches === 0) continue;

    // Precision: how much of the INI name matched (high = confident it's the right game)
    // Recall: how much of our search matched (lower weight — table names have extra junk)
    const precision = matches / hayWords.length;
    const recall    = matches / needleWords.length;
    const score     = precision * 0.65 + recall * 0.35;

    if (score > bestScore && precision >= 0.6) {
      bestScore = score;
      bestRom   = rom;
    }
  }
  return bestRom;
}

function findScoreFile(top10Dir, rom) {
  try {
    const files = fs.readdirSync(top10Dir).filter(f => /\.txt$/i.test(f));
    const names = files.map(f => ({ file: f, base: f.toLowerCase().replace(/\.txt$/i, '') }));

    // 1. Exact match: eatpm_l4
    const exact = names.find(n => n.base === rom);
    if (exact) return path.join(top10Dir, exact.file);

    // 2. Strip trailing _alphanumeric suffix to get base ROM family name.
    //    eatpm_11 → eatpm  (ini used nvram name, score file uses ROM version)
    //    tftc_400 → tftc
    const base = rom.replace(/_[a-z0-9]+$/i, '');
    if (base && base !== rom) {
      // Find any score file whose base name starts with the same ROM family
      const familyMatch = names.find(n => n.base === base || n.base.startsWith(base + '_'));
      if (familyMatch) return path.join(top10Dir, familyMatch.file);
    }

    // 3. Also try stripping the whole suffix after first underscore
    //    e.g. rom='eatpm_11', base2='eatpm'
    const firstUnderscore = rom.indexOf('_');
    if (firstUnderscore > 0) {
      const rootName = rom.slice(0, firstUnderscore);
      const rootMatch = names.find(n => n.base === rootName || n.base.startsWith(rootName + '_'));
      if (rootMatch) return path.join(top10Dir, rootMatch.file);
    }

    return null;
  } catch(e) { console.error('findScoreFile:', e.message); return null; }
}

function parseScoreFile(filePath) {
  try {
    const raw = fs.readFileSync(filePath);
    const text = raw.toString('utf8');
    const lines = text.split(/\r?\n/);

    console.log('[pinemhi] parsing:', filePath, '|', lines.length, 'lines');

    const scores = [];
    for (const line of lines) {
      const l = line.trim();
      if (!l) continue;
      // Must start with a rank digit
      if (!/^\d/.test(l)) continue;

      // Split on any whitespace runs (tabs or multiple spaces)
      const parts = l.split(/\s+/).filter(Boolean);
      if (parts.length < 2) continue;

      const rank = parseInt(parts[0]);
      if (isNaN(rank) || rank < 1 || rank > 100) continue;

      // Find the score token — could use . or , as thousand separator
      // Formats seen: "5.200.010" (EU dots) or "395,160" (US commas) or "5200010" (plain)
      let scoreVal = null, scoreIdx = -1;
      for (let i = 1; i < parts.length; i++) {
        const p = parts[i];
        // Strip thousand separators (dots or commas) to get raw digits
        const digits = p.replace(/[.,]/g, '');
        // Must be all digits and at least 2 digits long
        if (/^\d+$/.test(digits) && digits.length >= 2) {
          scoreVal = digits;
          scoreIdx = i;
          break;
        }
      }
      if (!scoreVal || parseInt(scoreVal) === 0) continue;

      // Find initials: first token that is not the rank, not the score,
      // and not a date/time (contains - or :)
      let initials = '';
      for (let i = 1; i < parts.length; i++) {
        if (i === scoreIdx) continue;
        const p = parts[i];
        if (/\d{4}-\d{2}/.test(p)) continue;  // date: 2026-04
        if (/^\d{2}:\d{2}/.test(p)) continue;  // time: 11:19
        if (/^[\d.,]+$/.test(p)) continue;      // another number
        initials = p;
        break;
      }

      scores.push({ rank, initials: initials || '—', score: scoreVal });
    }

    console.log('[pinemhi] parsed', scores.length, 'scores:', JSON.stringify(scores.slice(0,3)));
    return { scores: scores.slice(0, 10), rawLineCount: lines.length };
  } catch(e) {
    console.error('[pinemhi] parseScoreFile error:', e.message);
    return { scores: [], rawLineCount: 0 };
  }
}

// ── Window ────────────────────────────────────────────────────────────────────
let mainWindow = null;

function createWindow() {
  const data = loadData();
  const { windowWidth, windowHeight, displayIndex } = data.settings;
  const displays = screen.getAllDisplays();
  const target = displays[displayIndex] || displays[0];
  const { x: dx, y: dy } = target.bounds;
  const offX = data.settings.windowOffsetX || 0;
  const offY = data.settings.windowOffsetY || 0;

  const dispBounds = target.bounds; // full display including taskbar

  mainWindow = new BrowserWindow({
    width:  dispBounds.width,
    height: dispBounds.height,
    x: dispBounds.x + offX,
    y: dispBounds.y + offY,
    frame: false,
    resizable: false,
    movable: false,
    fullscreenable: false,
    alwaysOnTop: false,
    backgroundColor: '#050508',
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true, nodeIntegration: false,
    }
  });
  mainWindow.loadFile(path.join(__dirname, 'index.html'));

  // When window loses focus after a VPX launch, begin watching to reclaim it
  mainWindow.on('blur', () => {
    if (_vpxLaunched) {
      console.log('[focus] blur detected, vpxPid:', _vpxPid);
      startFocusWatch(_vpxPid);
    }
  });

  mainWindow.webContents.once('did-finish-load', () => {
    // Force the exact bounds after load in case OS adjusted them
    mainWindow.setBounds(dispBounds, false);
    mainWindow.focus();
  });
  mainWindow.webContents.on('before-input-event', (_, input) => {
    if (input.key === 'F12') mainWindow.webContents.toggleDevTools();
    if (input.key === 'Escape') app.quit();
  });
}

app.whenReady().then(createWindow);
app.on('window-all-closed', () => { if (process.platform !== 'darwin') app.quit(); });

// ── IPC ───────────────────────────────────────────────────────────────────────
ipcMain.handle('load-data', () => loadData());

ipcMain.handle('save-data', (_, data) => {
  const ok = saveData(data);
  if (ok && mainWindow) {
    const { windowWidth, windowHeight, displayIndex } = data.settings;
    const displays = screen.getAllDisplays();
    const target = displays[displayIndex] || displays[0];
    const offX = data.settings.windowOffsetX || 0;
    const offY = data.settings.windowOffsetY || 0;
    mainWindow.setBounds({
      x: target.bounds.x + offX,
      y: target.bounds.y + offY,
      width: target.bounds.width,
      height: target.bounds.height,
    }, false);

    // Invalidate ini cache if folder changed
    iniCache = null; iniCachePath = null;
  }
  return ok;
});

ipcMain.handle('get-displays', () =>
  screen.getAllDisplays().map((d, i) => ({
    index: i,
    label: `Display ${i+1} — ${d.bounds.width}×${d.bounds.height} at (${d.bounds.x},${d.bounds.y})`,
    bounds: d.bounds,
    isPrimary: d.id === screen.getPrimaryDisplay().id
  }))
);

// ── Focus watcher ─────────────────────────────────────────────────────────────
let _focusWatchTimer  = null;
let _focusWatchActive = false;
let _vpxLaunched      = false;
let _vpxPid           = null;

// Use PowerShell to forcibly bring our window to the foreground.
// This bypasses Electron's focus() limitations on Windows where another
// app (VPX) has locked the foreground privilege.
function refocusAfterVpx() {
  if (!mainWindow || mainWindow.isDestroyed()) return;
  _vpxLaunched = false;
  _vpxPid = null;
  // Simple: just show and focus. Works when window is not alwaysOnTop.
  mainWindow.show();
  mainWindow.focus();
  console.log('[focus] refocused');
}

function startFocusWatch(vpxPid) {
  console.log('[focus] watching for vpxPid', vpxPid, 'to exit');
  // Poll for VPX process to disappear, then focus once
  let count = 0;
  function poll() {
    count++;
    if (count > 240) { console.log('[focus] gave up'); return; } // 2 min max
    try {
      // process.kill(pid, 0) throws if pid doesn't exist — that means VPX exited
      process.kill(vpxPid, 0);
      // Still running — check again
      setTimeout(poll, 500);
    } catch(e) {
      // VPX is gone
      console.log('[focus] VPX gone after', count, 'polls, refocusing');
      setTimeout(refocusAfterVpx, 300);
    }
  }
  setTimeout(poll, 1000); // start checking after 1s
}

function stopFocusWatch() {
  // No-op — polling stops naturally when VPX exits
}

ipcMain.handle('launch-table', (_, { exePath, tablePath }) => {
  try {
    console.log('[launch] exe:', JSON.stringify(exePath));
    console.log('[launch] table:', JSON.stringify(tablePath));

    if (!tablePath) return { ok: false, error: 'No table path set — edit the table and set the VPX file path.' };
    if (!exePath)   return { ok: false, error: 'No VPinball exe set — check Settings.' };

    // Spawn VPX directly (no shell) so we track the actual process.
    // Pass args as array — execFile handles quoting correctly on Windows.
    const args = ['-LessCPUthreads', '-ExtMinimized', '-play', tablePath];
    console.log('[launch] exe:', exePath, 'args:', args);

    const proc = spawn(exePath, args, {
      detached: true,
      stdio: 'ignore',
      shell: false,
      windowsHide: false,
    });

    console.log('[launch] pid:', proc.pid);

    // proc.on('close') fires when the actual VPX process exits
    proc.on('close', (code) => {
      console.log('[launch] process closed with code:', code);
      // Process closed — try immediate refocus too
      setTimeout(() => {
        if (mainWindow && !mainWindow.isDestroyed()) {
      
          mainWindow.show();
          mainWindow.focus();
        }
      }, 500);
    });

    proc.on('error', (err) => {
      console.error('[launch] spawn error:', err.message);
    });

    proc.unref();

    // Mark that we launched — blur handler will start the focus watch
    // once VPX actually takes focus from us
    _vpxLaunched = true;
    _vpxPid = proc.pid; // store for focus watcher

    // Start watching immediately — don't rely solely on blur event
    // (blur may not fire if VPX goes fullscreen on same display)
    startFocusWatch(proc.pid);

    return { ok: true };
  } catch(e) {
    console.error('[launch] error:', e.message);
    return { ok: false, error: e.message };
  }
});

// Scan a folder for .vpx files, return list of {name, path}
ipcMain.handle('scan-folder', (_, { folderPath, existingPaths, deletedPaths }) => {
  try {
    if (!folderPath || !fs.existsSync(folderPath)) return { ok: false, error: 'Folder not found', files: [] };
    const existing = new Set((existingPaths || []).map(p => p.toLowerCase()));
    const deleted  = new Set((deletedPaths  || []).map(p => p.toLowerCase()));
    const results = [];
    function recurse(dir) {
      let entries;
      try { entries = fs.readdirSync(dir, { withFileTypes: true }); } catch { return; }
      for (const e of entries) {
        const full = path.join(dir, e.name);
        if (e.isDirectory()) { recurse(full); continue; }
        if (e.name.toLowerCase().endsWith('.vpx')) {
          const lc = full.toLowerCase();
          if (!existing.has(lc) && !deleted.has(lc)) {
            // Derive a clean name: strip extension, strip trailing version junk
            const rawName = e.name.replace(/\.vpx$/i, '');
            results.push({ name: rawName, path: full });
          }
        }
      }
    }
    recurse(folderPath);
    return { ok: true, files: results };
  } catch(e) { return { ok: false, error: e.message, files: [] }; }
});

// Read PINemHi scores for a table
ipcMain.handle('get-pinemhi-scores', (_, { pinemhiFolder, tableName, wheelFileName, romOverride }) => {
  try {
    if (!pinemhiFolder) return { ok: false, error: 'No PINemHi folder set', rom: null, scores: [] };
    if (!fs.existsSync(pinemhiFolder)) return { ok: false, error: `Folder not found: ${pinemhiFolder}`, rom: null, scores: [] };

    const iniPath = path.join(pinemhiFolder, 'pinemhi.ini');
    if (!fs.existsSync(iniPath)) return { ok: false, error: `pinemhi.ini not found in: ${pinemhiFolder}`, rom: null, scores: [] };

    const top10Dir = path.join(pinemhiFolder, 'PINemHi LeaderBoard', 'TOP10_Personal');
    if (!fs.existsSync(top10Dir)) return { ok: false, error: `TOP10_Personal not found at: ${top10Dir}`, rom: null, scores: [] };

    // ROM: use override if set, else look up in ini
    let rom = romOverride ? romOverride.toLowerCase().trim() : null;
    if (!rom) {
      const iniMap = loadPinemhiIni(iniPath);
      if (!iniMap) return { ok: false, error: 'Could not parse pinemhi.ini', rom: null, scores: [] };
      rom = fuzzyMatchIni(iniMap, wheelFileName || '', tableName);
    }
    if (!rom) return { ok: true, rom: null, scores: [], noMatch: true };

    const scoreFile = findScoreFile(top10Dir, rom);
    if (!scoreFile) return { ok: true, rom, scores: [], noScoreFile: true };

    const { scores, rawLineCount } = parseScoreFile(scoreFile);
    return { ok: true, rom, scores, rawLineCount };
  } catch(e) {
    console.error('get-pinemhi-scores:', e);
    return { ok: false, error: e.message, rom: null, scores: [] };
  }
});


// Debug: dump TOP10_Personal dir + raw file content for diagnosis
ipcMain.handle('debug-pinemhi', (_, { pinemhiFolder, rom }) => {
  try {
    const top10Dir = path.join(pinemhiFolder, 'PINemHi LeaderBoard', 'TOP10_Personal');
    const dirExists = fs.existsSync(top10Dir);
    const files = dirExists ? fs.readdirSync(top10Dir) : [];
    const romFiles = files.filter(f => f.toLowerCase().includes(rom.toLowerCase()));
    let rawContent = null;
    let firstLineChars = null;
    const exactFile = files.find(f => f.toLowerCase().replace(/\.txt$/i,'') === rom.toLowerCase());
    if (exactFile) {
      const buf = fs.readFileSync(path.join(top10Dir, exactFile));
      rawContent = buf.toString('utf8');
      // Find first data line and show its char codes
      const dataLine = rawContent.split(/\r?\n/).find(l => /^\s*\d/.test(l.trim()));
      if (dataLine) {
        firstLineChars = [...dataLine].slice(0,30).map(c => c.charCodeAt(0)).join(',');
      }
    }
    return { dirExists, top10Dir, allFiles: files.slice(0, 30), romFiles, exactFile, rawContent, firstLineChars };
  } catch(e) { return { error: e.message }; }
});


// Debug: read raw bytes of a file and return hex + text
ipcMain.handle('read-raw-file', (_, { filePath }) => {
  try {
    const buf = fs.readFileSync(filePath);
    const lines = buf.toString('utf8').split(/\r?\n/);
    // For each of the first 20 lines, return text + char codes
    const lineData = lines.slice(0, 20).map(line => ({
      text: line,
      codes: [...line].slice(0, 50).map(c => c.charCodeAt(0)),
    }));
    return { ok: true, lineData, totalLines: lines.length };
  } catch(e) { return { ok: false, error: e.message }; }
});


// Check which library tables no longer exist on disk
ipcMain.handle('check-missing-files', (_, { tablePaths }) => {
  const missing = (tablePaths || []).filter(p => {
    try { return !fs.existsSync(p); } catch { return true; }
  });
  return { missing };
});


// Flash a colored overlay on a display so user can identify which is which
ipcMain.handle('identify-display', (_, displayIndex) => {
  const displays = screen.getAllDisplays();
  const target = displays[displayIndex] || displays[0];
  const { x, y, width, height } = target.bounds;

  const flashWin = new BrowserWindow({
    x, y, width, height,
    frame: false, transparent: false, alwaysOnTop: true,
    backgroundColor: '#e8640a',
    skipTaskbar: true,
    webPreferences: { nodeIntegration: false },
  });
  flashWin.loadURL('data:text/html,<body style="background:#e8640a;display:flex;align-items:center;justify-content:center;height:100vh;margin:0"><div style="font-size:80px;font-weight:900;color:white;font-family:sans-serif">DISPLAY ' + (displayIndex + 1) + '</div></body>');
  flashWin.setKiosk(true);
  setTimeout(() => { try { flashWin.close(); } catch {} }, 2000);
  return true;
});

ipcMain.handle('browse-exe',    async () => { const r = await dialog.showOpenDialog({ title: 'Select VPinballX64.exe', filters: [{ name: 'Executable', extensions: ['exe'] }], properties: ['openFile'] }); return r.canceled ? null : r.filePaths[0]; });
ipcMain.handle('browse-vpx',    async () => { const r = await dialog.showOpenDialog({ title: 'Select VPX Table File', filters: [{ name: 'Visual Pinball Tables', extensions: ['vpx','vpt'] }, { name: 'All Files', extensions: ['*'] }], properties: ['openFile'] }); return r.canceled ? null : r.filePaths[0]; });
ipcMain.handle('browse-folder', async () => { const r = await dialog.showOpenDialog({ title: 'Select Folder', properties: ['openDirectory'] }); return r.canceled ? null : r.filePaths[0]; });

ipcMain.handle('list-wheel-images', (_, folderPath) => {
  try {
    if (!folderPath || !fs.existsSync(folderPath)) return [];
    const exts = new Set(['.png', '.jpg', '.jpeg', '.webp', '.gif']);
    return fs.readdirSync(folderPath).filter(f => exts.has(path.extname(f).toLowerCase())).map(f => ({ name: f, fullPath: path.join(folderPath, f) }));
  } catch { return []; }
});

ipcMain.handle('read-image-base64', (_, filePath) => {
  try {
    const buf = fs.readFileSync(filePath);
    const ext = path.extname(filePath).toLowerCase().replace('.', '');
    const mime = ext === 'jpg' ? 'image/jpeg' : `image/${ext}`;
    return `data:${mime};base64,${buf.toString('base64')}`;
  } catch { return null; }
});

ipcMain.handle('quit', () => app.quit());
