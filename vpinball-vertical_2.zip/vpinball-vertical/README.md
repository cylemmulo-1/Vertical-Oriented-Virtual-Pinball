# VPinball Vertical — Cabinet Frontend

A vertical/portrait-oriented frontend for Visual Pinball X tables, designed for
virtual pinball cabinets where VPX cabinet mode rotates the playfield display.

---

## The Display Rotation Problem

When VPX runs in cabinet mode it rotates your playfield monitor via Windows display
settings (90° or 270°). Your physical monitor is mounted portrait (tall), but
**Windows still reports it as a landscape resolution** — the native width×height,
not the swapped version.

**Example:** A 2560×1440 monitor rotated 90° is still reported by Windows as
**2560×1440 landscape**. The desktop just renders rotated within that space.

This app handles it by:
1. Opening an Electron window at the **full landscape size** (e.g. 2560×1440)
   so it fills the entire rotated display
2. CSS-rotating the app content **90° counter-clockwise** so everything appears
   upright when viewed on the physically rotated portrait monitor

This means you design the UI as 1440×2560 in CSS terms, but the actual window
Windows sees is 2560×1440 — the rotation is purely visual via CSS transform.

---

## Install & Run

```bash
# Install dependencies (first time only)
npm install

# Run the app
npm start
```

## Build a Windows installer

```bash
npm run build
# Output: dist/VPinball Vertical Setup.exe
```

---

## First Launch Setup

1. Click **⚙ Settings** in the top-right header
2. Set your **VPinballX64.exe** path (e.g. `C:\VPinball\VPinballX64.exe`)
3. Set your **Wheel Images Folder** (e.g. `C:\PinballY\Media\Visual Pinball X\Wheel Images`)
4. Under **Display / Monitor**, pick the display that is your physical playfield monitor
5. Verify **Window Width = 1440** and **Window Height = 2560** (for a 2560×1440 rotated monitor)
   - If your monitor is a different resolution, swap the dimensions accordingly
6. Save — the window will reposition itself to that display

---

## Adding Tables

Click **＋** in the header. Fill in:
- **Table Name** — used for wheel image fuzzy matching
- **Manufacturer / Year** — shown in the detail pane
- **VPX File Path** — the `.vpx` file to launch
- **Wheel Image** — leave blank to auto-match from your wheel folder
- **Categories** — tag the table for filtering
- **Notes** — version info, mods, etc.

---

## Wheel Image Matching

When no specific wheel image path is set for a table, the app fuzzy-matches the
table name against filenames in your wheel images folder. It scores matches by:
- Exact name match (100%)
- Prefix match (90%)
- Word overlap (up to 70%)

Tables need a score above 30% threshold to get a match. If a table isn't matching,
set the wheel path manually in the Edit dialog.

---

## Keyboard Shortcuts

| Key | Action |
|-----|--------|
| `Enter` | Play selected table |
| `Ctrl+N` | Add new table |
| `Escape` | Close modal / quit |
| `F12` | Toggle DevTools (dev mode) |

Double-clicking a table row also launches it immediately.

---

## Data Storage

All table data is stored in:
`%APPDATA%\vpinball-vertical\vpinball-vertical.json`

The VPX files themselves are never moved or modified.
